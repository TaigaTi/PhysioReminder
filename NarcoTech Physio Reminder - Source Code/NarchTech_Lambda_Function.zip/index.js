/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');
const SKILL_NAME = "Reminder Assistant";//name of skill

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        //const speakOutput = 'Welcome, to NarcoTech\'s Reminder Assistant. You can say remember my appointment date or help. Which do you want to try?';
        const speakOutput = 'Welcome, to NarcoTech\'s Reminder Assistant. You can <break time="0.5s"/> check reminders <break time="1s"/> create a reminder <break time="1s"/> or delete a reminder. <break time="1s"/> Which would you like to try?';
        //Welcomes the user to the skill when launched

        // declares session variables below
        let sessionAttributes; //initialisation of session var
        sessionAttributes = {
            "date": '',
            "time": '',
            // "name":'thename',
            "therapist": '',
            // "tName": '', //remember to remove this test variable 
        };

        //committing the session attribute var and set it 
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const ReminderIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ReminderIntent';
    },
    handle(handlerInput) {
        //const speakOutput = 'Hello World!';
        var AWS = require('aws-sdk');//setup for using dynamo db
        var ddb = new AWS.DynamoDB({apiVersion: '2012-10-08'});//setup for using dyanamodb
        var speakOutput = "";
        //var docClient = new AWS.DynamoDB.DocumentClient();//setup for using document client scan
        
        let date = handlerInput.requestEnvelope.request.intent.slots.date.value; //slot (variable) used to capture the reminder date
        let time = handlerInput.requestEnvelope.request.intent.slots.time.value;//slot used to capture the reminder time
        let therapist = handlerInput.requestEnvelope.request.intent.slots.therapist.value;//slot used to capture the reminder appointment
        let pId = handlerInput.requestEnvelope.session.user.userId;//captures the users unique id
        let reqId = "d"+date+"t"+time + "p" + pId;//creates the appointmentid from the date, time and user id
        let foundTherapist = "";//will contain a conflicting appointment's therapist
        
        // let name = handlerInput.requestEnvelope.request.intent.slots.name.value;
        
        // let speakOutput = "";
        // let confirmationMsg = "";
        
        // if (intent.confirmationStatus === 'CONFIRMED') {
        //     confirmationMsg = 
        //     speakOutput =  confirmationMsg;
        // }
        // else {
        //      = "Error. PLease try again";
        // }
        
        //the above code confirms that the appointment reminder was set

        //get a session attribute 
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.date = date; //passing date variable to session variable
        sessionAttributes.time = time;//passing time variable to session variables
        sessionAttributes.therapist = therapist;//passing therapist to session variables
        
        
        var params = {
            ExpressionAttributeNames:{
                "#therapist":"therapistOfApp"
            },
            ExpressionAttributeValues: {
                ":value": {
                    S: reqId
                }
            }, 
            FilterExpression: "id = :value",
            ProjectionExpression: "#therapist",
            TableName : "appointments"
        };
        console.log("ATTEMPTING SCAN WITH ID: "+reqId);
        //*****************************************
        //***************WORKS
        
        return ddb.scan(params, function(err, data) {//tries to scan database for appointment with id of reqId, to make sure that there is no conflict;
            if (err) {console.log(err, err.stack);} // an error occurred
            else{//if successful
                console.log(data);
                /* This is the format data follows with how parameter is set
                data = {
                    Items: [
                    { therapistOfApp:
                        {S:"sally"}
                    } 
                    ],
                    Count: 1,
                    ScannedCount: 2
                }
              */
                let scanResults = data.Items;//sets scanResults to the Items array, which is an array of appointment details matching the scan parameters
                console.log("ITEMS: "+scanResults);
                if (scanResults.length>0){//if the scan finds conflicts
                    for(var i = 0,l=scanResults.length; i<l; i++){
                        foundTherapist = scanResults[i].therapistOfApp.S
                        console.log("CONFLICTING THERAPIST NAME: "+foundTherapist);
                        console.log("WOULD RECORD CONFLICT ON "+date+" AT "+time);
                    }
                    speakOutput = "You have a conflicting appointment scheduled with "+foundTherapist+" on "+date+" at "+ time+".";
                }
                else{
                    console.log("VALIDATED. Attempting to add appointment");
                    let params2 = {
                        TableName: 'appointments', //place the correct table name associaded with your alexa hosted skill here as was demonstrated in the video demonstration.
                        Item: {
                            'id' : {S: reqId},
                            'dateOfApp' : {S: date},
                            'timeOfApp' : {S: time},
                            'therapistOfApp' : {S: therapist},
                            'patientId':{S:pId}//just added
                        }
                    };
                    ddb.putItem(params2, function(err, data){
                    if(err){
                    console.log(err);
                    // speakOutput = err;
                    } else{
                    console.log('Success');
                    }
                    });
                    speakOutput = "Your appointment is on " + date + " at " + time + " with Physiotherapist " + therapist + 
                             " and the date has been saved.";
                    
                }
            }
            return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt()
            .getResponse();
        })
        .catch((error) => {
        console.error("Unable to scan. Error:", JSON.stringify(error, null, 2));
            
        });
        //************************WORKS
        //********************************
    }
};

const CheckingAppDetailsIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CheckingAppDetails';
    },
    handle(handlerInput) {
        const pId = handlerInput.requestEnvelope.session.user.userId;
        console.log('User ID: '+pId);
        let date = handlerInput.requestEnvelope.request.intent.slots.date.value;
        let time = handlerInput.requestEnvelope.request.intent.slots.time.value;
        let speakOutput = "";
        
        var AWS = require("aws-sdk");

        var ddb = new AWS.DynamoDB({apiVersion: '2012-10-08'});//setup for using dyanamodb
        //var docClient = new AWS.DynamoDB.DocumentClient();
        let results = "";
       
        var params = {
            ExpressionAttributeNames:{
                "#therapist":"therapistOfApp",
                "#date":"dateOfApp",
                "#time":"timeOfApp"
            },
            ExpressionAttributeValues: {
                ":value": {
                    S: pId
                }
            }, 
            FilterExpression: "patientId = :value",
            ProjectionExpression: "#therapist,#date,#time",
            TableName : "appointments"
        };
        
        console.log("ATTEMPTING TO SCAN USING PATIENT: "+pId);
        return ddb.scan(params, function(err,data) {
            if (err) {
                console.error("Unable to scan. Error:", JSON.stringify(err, null, 2));
            } else {
                console.log("Scan succeeded.");
                console.log("data = " +  JSON.stringify(data,null,2));
                
                let scanResults = data.Items;//sets scanResults to the Items array, which is an array of appointment details matching the scan parameters
                console.log("ITEMS: "+scanResults);
                
                if (scanResults.length>0){//if the scan finds conflicts
                    for(var i = 0,l=scanResults.length; i<l; i++){
                        if(speakOutput == "")
                            speakOutput = "Your appointments are as follows:\n";
                        speakOutput += "Appointment with physiotherapist "+scanResults[i].therapistOfApp.S+" on "+scanResults[i].dateOfApp.S+" at "+scanResults[i].timeOfApp.S+".\n";
                    }
                }
                else{
                    speakOutput="You currently have no appointment reminders. or Amazon is acting up again.";
                }
            }
            
            return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt()
            .getResponse();
            
        })
        .catch((error) => {
        console.error("Unable to scan. Error:", JSON.stringify(error, null, 2));
            
        });

    }

};

const DeleteAppIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'DeleteAppIntent';
    },
    handle(handlerInput) {
        console.log("DELETE IS EXECUTED");
        let speakOutput = "";
        var AWS = require("aws-sdk");
        let ddb = new AWS.DynamoDB({apiVersion: '2012-10-08'});//setup for using dyanamodb
        
        const pId = handlerInput.requestEnvelope.session.user.userId;
        let date = handlerInput.requestEnvelope.request.intent.slots.date.value;
        let time = handlerInput.requestEnvelope.request.intent.slots.time.value;
        let reqId = "d"+date+"t"+time+"p"+pId;
        
        var params = {
            Key:{
                "id": {
                 S: reqId
                }, 
               "timeOfApp": {
                 S: time
                }
            },
            TableName : "appointments"
        };
        
        console.log("ID BEING USED: "+reqId);
        console.log("DATE BEING USED: "+date);
        return ddb.deleteItem(params, function(err, data) {
            if (err) console.log(err, err.stack); // an error occurred
            else{//successful response
                console.log(data);
                console.log("DELETE SUCCESS");
                speakOutput = "Deleted appointment on "+ date + " at "+ time + ".";
            }
            return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt()
            .getResponse();
        })
        .catch((error) => {
        console.error("Unable to scan. Error:", JSON.stringify(error, null, 2));
            
        });
        
    }

};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say keep my date or remember my appointment date.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I don\'t know about that. Please try again.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        ReminderIntentHandler,
        CheckingAppDetailsIntentHandler,
        DeleteAppIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();